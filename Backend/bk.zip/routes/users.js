const express = require("express");
const {
	RegisterUser,
	LoginUser,
	getUsers,
	getOneUser,
} = require("../controllers/userController");
const { authenticateToken, authorizeRole } = require("../middlewares/auth");
const router = express.Router();

router.post("/register", RegisterUser);
router.post("/login", LoginUser);
router.get("/users", authenticateToken, authorizeRole("admin"), getUsers);
router.get("/user/:id", authenticateToken, getOneUser);

module.exports = router;
