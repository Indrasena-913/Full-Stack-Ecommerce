const express = require("express");
const {
	createOrder,
	getOrders,
	getOrderById,
	updateOrder,
	deleteOrder,
	updateOrderStatus,
} = require("../controllers/orderController");
const { authenticateToken, authorizeRole } = require("../middlewares/auth");

const router = express.Router();

router.post("/orders", authenticateToken, createOrder);
router.get("/orders", authenticateToken, authorizeRole("admin"), getOrders);
router.get("/orders/:id", authenticateToken, getOrderById);
router.put(
	"/orders/:id",
	authenticateToken,
	authorizeRole("admin"),
	updateOrder
);
router.delete(
	"/orders/:id",
	authenticateToken,
	authorizeRole("admin"),
	deleteOrder
);
router.patch(
	"/orders/:id/status",
	authenticateToken,
	authorizeRole("admin"),
	updateOrderStatus
);

module.exports = router;
