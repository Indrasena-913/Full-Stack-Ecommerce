const express = require("express");
const {
	addToWishlist,
	getWishlist,
	removeFromWishlist,
} = require("../controllers/wishlistController");

const router = express.Router();

// Wishlist Routes
router.post("/wishlist", addToWishlist);
router.get("/wishlist/:userId", getWishlist);
router.delete("/wishlist", removeFromWishlist);

module.exports = router;
