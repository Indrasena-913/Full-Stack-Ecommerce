const pool = require("../models/db");

exports.createOrder = async (req, res) => {
	try {
		const { user_id, products, total_amount, status, payment_status } =
			req.body;

		// Extract product IDs from the request
		const productIds = products.map((p) => p.product_id);

		// Check if all requested product IDs exist in the products table
		const productCheckQuery = await pool.query(
			"SELECT id FROM products WHERE id = ANY($1)",
			[productIds]
		);

		// If any product ID is missing, reject the order
		const existingProductIds = productCheckQuery.rows.map((row) => row.id);
		const missingProducts = productIds.filter(
			(id) => !existingProductIds.includes(id)
		);

		if (missingProducts.length > 0) {
			return res.status(400).json({
				error: "Some products do not exist",
				missing_products: missingProducts,
			});
		}

		// Convert products to JSON string for PostgreSQL jsonb column
		const formattedProducts = JSON.stringify(products);

		// Insert order into the orders table
		const newOrder = await pool.query(
			"INSERT INTO orders (user_id, products, total_amount, status, payment_status) VALUES ($1, $2::jsonb, $3, $4, $5) RETURNING *",
			[user_id, formattedProducts, total_amount, status, payment_status]
		);

		res
			.status(201)
			.json({ message: "Order created successfully", order: newOrder.rows[0] });
	} catch (error) {
		console.error("Error creating order:", error);
		res.status(500).json({ error: "Internal server error" });
	}
};
exports.getOrders = async (req, res) => {
	try {
		const result = await pool.query("SELECT * FROM orders");
		res.json(result.rows);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: "Internal Server Error" });
	}
};

exports.getOrderById = async (req, res) => {
	const { id } = req.params;

	try {
		const result = await pool.query("SELECT * FROM orders WHERE id = $1", [id]);

		if (result.rows.length === 0) {
			return res.status(404).json({ message: "Order not found" });
		}

		res.json(result.rows[0]);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: "Internal Server Error" });
	}
};

exports.updateOrder = async (req, res) => {
	const { id } = req.params;
	const { status, payment_status } = req.body;

	try {
		const result = await pool.query(
			"UPDATE orders SET status = $1, payment_status = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3 RETURNING *",
			[status, payment_status, id]
		);

		if (result.rows.length === 0) {
			return res.status(404).json({ message: "Order not found" });
		}

		res.json({ message: "Order updated successfully", order: result.rows[0] });
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: "Internal Server Error" });
	}
};

exports.updateOrderStatus = async (req, res) => {
	const { id } = req.params;
	const { status } = req.body;

	const validStatuses = ["Pending", "Shipped", "Delivered"];
	if (!validStatuses.includes(status)) {
		return res.status(400).json({ error: "Invalid order status" });
	}

	try {
		const result = await pool.query(
			"UPDATE orders SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *",
			[status, id]
		);

		if (result.rows.length === 0) {
			return res.status(404).json({ message: "Order not found" });
		}

		res.json({ message: "Order status updated", order: result.rows[0] });
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: "Internal Server Error" });
	}
};

exports.deleteOrder = async (req, res) => {
	const { id } = req.params;

	try {
		const result = await pool.query(
			"DELETE FROM orders WHERE id = $1 RETURNING *",
			[id]
		);

		if (result.rows.length === 0) {
			return res.status(404).json({ message: "Order not found" });
		}

		res.json({ message: "Order deleted successfully" });
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: "Internal Server Error" });
	}
};
