const pool = require("../models/db");

// 📌 Add to Cart
exports.addToCart = async (req, res) => {
	try {
		const { user_id, product_id, quantity } = req.body;

		// Check if product already exists in the cart
		const checkQuery = `SELECT * FROM cart WHERE user_id = $1 AND product_id = $2`;
		const checkResult = await pool.query(checkQuery, [user_id, product_id]);

		if (checkResult.rows.length > 0) {
			// Update quantity if product exists
			const updateQuery = `
        UPDATE cart SET quantity = quantity + $3 
        WHERE user_id = $1 AND product_id = $2 RETURNING *;
      `;
			const updatedCart = await pool.query(updateQuery, [
				user_id,
				product_id,
				quantity,
			]);
			return res.json(updatedCart.rows[0]);
		} else {
			// Insert new product into cart
			const insertQuery = `
        INSERT INTO cart (user_id, product_id, quantity)
        VALUES ($1, $2, $3) RETURNING *;
      `;
			const newCart = await pool.query(insertQuery, [
				user_id,
				product_id,
				quantity,
			]);
			return res.status(201).json(newCart.rows[0]);
		}
	} catch (error) {
		res.status(500).json({ error: error.message });
	}
};

// 📌 Get Cart
exports.getCart = async (req, res) => {
	try {
		const { userId } = req.params;
		const { rows } = await pool.query(`SELECT * FROM cart WHERE user_id = $1`, [
			userId,
		]);
		res.json(rows);
	} catch (error) {
		res.status(500).json({ error: error.message });
	}
};

// 📌 Update Cart Quantity
exports.updateCart = async (req, res) => {
	try {
		const { user_id, product_id, quantity } = req.body;
		const { rows } = await pool.query(
			`UPDATE cart SET quantity = $3 WHERE user_id = $1 AND product_id = $2 RETURNING *`,
			[user_id, product_id, quantity]
		);
		res.json(rows[0]);
	} catch (error) {
		res.status(500).json({ error: error.message });
	}
};

// 📌 Remove from Cart
exports.removeFromCart = async (req, res) => {
	try {
		const { user_id, product_id } = req.body;
		await pool.query(
			`DELETE FROM cart WHERE user_id = $1 AND product_id = $2`,
			[user_id, product_id]
		);
		res.json({ message: "Product removed from cart" });
	} catch (error) {
		res.status(500).json({ error: error.message });
	}
};
