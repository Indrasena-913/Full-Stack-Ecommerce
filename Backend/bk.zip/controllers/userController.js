const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const pool = require("../models/db");
exports.RegisterUser = async (req, res) => {
	const { name, email, password, role, address, phone_number } = req.body;

	if (!name || !email || !password || !role || !address || !phone_number) {
		return res.status(400).json({ message: "Missing required fields" });
	}

	if (role !== "admin" && role !== "user") {
		return res
			.status(400)
			.json({ message: "Invalid role, must be 'admin' or 'user'" });
	}

	try {
		const hashedPassword = await bcrypt.hash(password, 10);
		const result = await pool.query(
			"INSERT INTO users (name, email, password, role, address, phone_number) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id",
			[name, email.toLowerCase(), hashedPassword, role, address, phone_number]
		);

		res
			.status(201)
			.json({ message: `User registered with ID: ${result.rows[0].id}` });
	} catch (error) {
		if (error.code === "23505") {
			return res.status(409).json({ message: "User already exists" });
		}
		console.error(error);
		res.status(500).json({ message: "Internal Server Error" });
	}
};

exports.LoginUser = async (req, res) => {
	const { email, password } = req.body;

	if (!email || !password) {
		return res.status(400).json({ message: "Missing fields" });
	}

	try {
		const result = await pool.query("SELECT * FROM users WHERE email = $1", [
			email.toLowerCase(),
		]);

		if (result.rows.length === 0) {
			return res.status(401).json({ message: "Invalid credentials" });
		}

		const user = result.rows[0];
		const passwordMatch = await bcrypt.compare(password, user.password);

		if (!passwordMatch) {
			return res.status(401).json({ message: "Invalid credentials" });
		}

		const token = jwt.sign(
			{ userId: user.id, role: user.role },
			process.env.JWT_SECRET,
			{ expiresIn: "8h" }
		);

		res.json({ token });
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: "Internal server error" });
	}
};

exports.getUsers = async (req, res) => {
	try {
		const result = await pool.query(
			"SELECT id, name, email, role, address, phone_number FROM users"
		);
		res.json(result.rows);
	} catch (error) {
		console.error("Error fetching users:", error);
		res.status(500).json({ message: "Internal Server Error" });
	}
};

exports.getOneUser = async (req, res) => {
	try {
		const { id } = req.params;

		const result = await pool.query(
			"SELECT id, name, email, role, address, phone_number FROM users WHERE id = $1",
			[id]
		);

		if (result.rows.length === 0) {
			return res.status(404).json({ message: "User not found" });
		}

		res.json(result.rows[0]);
	} catch (error) {
		console.error("Error fetching user:", error);
		res.status(500).json({ message: "Internal Server Error" });
	}
};
